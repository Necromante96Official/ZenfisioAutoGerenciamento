/**
 * Export/Import Manager - Interface para exportar e importar dados
 */

class ExportImportManager {
    constructor() {
        this.setupEventListeners();
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Será configurado após o DOM estar pronto
        document.addEventListener('DOMContentLoaded', () => {
            this.attachListeners();
        });
    }

    /**
     * Attach listeners aos botões
     */
    attachListeners() {
        const exportBtn = document.getElementById('exportBtn');
        const importBtn = document.getElementById('importBtn');
        const importInput = document.getElementById('importInput');

        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.handleExport());
        }

        if (importBtn) {
            importBtn.addEventListener('click', () => {
                importInput?.click();
            });
        }

        if (importInput) {
            importInput.addEventListener('change', (e) => this.handleImport(e));
        }
    }

    /**
     * Handle export
     */
    handleExport() {
        try {
            if (!window.dataManager) {
                this.showNotification('Gerenciador de dados não disponível', 'error');
                return;
            }

            const jsonData = window.dataManager.exportData();
            
            if (!jsonData) {
                this.showNotification('Erro ao gerar arquivo de exportação', 'error');
                return;
            }

            // Cria e baixa arquivo
            const blob = new Blob([jsonData], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `zenfisio_backup_${new Date().getTime()}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            this.showNotification('✅ Dados exportados com sucesso!', 'success');
        } catch (error) {
            console.error('Erro ao exportar:', error);
            this.showNotification('Erro ao exportar dados', 'error');
        }
    }

    /**
     * Handle import
     */
    handleImport(event) {
        try {
            const file = event.target.files?.[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const jsonString = e.target?.result;
                    
                    if (!window.dataManager) {
                        this.showNotification('Gerenciador de dados não disponível', 'error');
                        return;
                    }

                    const result = window.dataManager.importData(jsonString);

                    if (result.success) {
                        this.showNotification(
                            `✅ ${result.message}\n📊 Evoluções: ${result.metadata.evolucoesCont} | Financeiro: ${result.metadata.financeiroCont}`,
                            'success',
                            5000
                        );
                        
                        // Recarrega página após 2 segundos para aplicar dados
                        setTimeout(() => {
                            window.location.reload();
                        }, 2000);
                    } else {
                        this.showNotification(`❌ Erro na importação: ${result.message}`, 'error');
                    }
                } catch (error) {
                    console.error('Erro ao processar arquivo:', error);
                    this.showNotification('Erro ao processar arquivo JSON', 'error');
                }
            };

            reader.readAsText(file);
            
            // Limpa input para permitir re-upload do mesmo arquivo
            event.target.value = '';
        } catch (error) {
            console.error('Erro ao importar:', error);
            this.showNotification('Erro ao importar dados', 'error');
        }
    }

    /**
     * Show notification
     */
    showNotification(message, type = 'info', duration = 4000) {
        if (window.notificationSystem) {
            window.notificationSystem.show(message, type, duration);
        } else if (window.notify) {
            window.notify.show(message, type, duration);
        }
    }

    /**
     * Exporta dados de forma manual
     */
    manualExport() {
        this.handleExport();
    }

    /**
     * Obtém dados para sincronização
     */
    getSyncData() {
        if (!window.dataManager) return null;
        return window.dataManager.exportData();
    }
}

// Instância global
let exportImportManager;

document.addEventListener('DOMContentLoaded', () => {
    exportImportManager = new ExportImportManager();
    window.exportImportManager = exportImportManager;
});
