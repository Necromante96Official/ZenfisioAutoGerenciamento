/**
 * PARSER-AGENDAMENTOS.JS
 * Módulo responsável por fazer o parse de mensagens de agendamento
 * e extrair os dados para análise financeira
 */

class AgendamentoParser {
    constructor() {
        this.agendamentos = [];
    }

    /**
     * Faz o parse do conteúdo colado
     * @param {string} content - Conteúdo da mensagem
     * @returns {Object|null} Objeto com dados do agendamento ou null se inválido
     */
    parse(content) {
        if (!content || content.trim() === '') {
            return null;
        }

        const lines = content.split('\n');
        const agendamento = {
            horario: null,
            fisioterapeuta: null,
            paciente: null,
            celular: null,
            convenio: null,
            status: null,
            procedimentos: null,
            repetido: null,
            periodo: null,
            valorAtendimento: 0,
            tipoConvenio: null,
            dataProcessamento: new Date(),
            mes: null,
            ano: null,
            isIsento: false,
            isPagante: false,
            isAtendido: false
        };

        // Parse linha por linha
        lines.forEach(line => {
            const cleanLine = line.trim();

            // Horário
            if (cleanLine.startsWith('Horário:')) {
                agendamento.horario = cleanLine.replace('Horário:', '').trim();
            }

            // Fisioterapeuta
            if (cleanLine.startsWith('Fisioterapeuta:')) {
                agendamento.fisioterapeuta = cleanLine.replace('Fisioterapeuta:', '').trim();
            }

            // Paciente
            if (cleanLine.startsWith('Paciente:')) {
                agendamento.paciente = cleanLine.replace('Paciente:', '').trim();
            }

            // Celular
            if (cleanLine.startsWith('Celular:')) {
                agendamento.celular = cleanLine.replace('Celular:', '').trim();
            }

            // Convênio
            if (cleanLine.startsWith('Convênio:') || cleanLine.startsWith('Convenio:')) {
                agendamento.convenio = cleanLine.replace(/Conv[êe]nio:/, '').trim();
            }

            // Status
            if (cleanLine.startsWith('Status:')) {
                agendamento.status = cleanLine.replace('Status:', '').trim();
                agendamento.isAtendido = agendamento.status.toLowerCase() === 'atendido';
            }

            // Procedimentos
            if (cleanLine.startsWith('Procedimentos:')) {
                agendamento.procedimentos = cleanLine.replace('Procedimentos:', '').trim();
                
                // Verifica se é isento (case-insensitive)
                agendamento.isIsento = /isento/i.test(agendamento.procedimentos);
            }

            // Repetido
            if (cleanLine.startsWith('Repetido:')) {
                agendamento.repetido = cleanLine.replace('Repetido:', '').trim();
            }

            // Período
            if (cleanLine.startsWith('Período:') || cleanLine.startsWith('Periodo:')) {
                const periodoText = cleanLine.replace(/Per[íi]odo:/, '').trim();
                agendamento.periodo = periodoText;
                
                // Extrai data inicial para determinar mês/ano
                const dataMatch = periodoText.match(/(\d{2})\/(\d{2})\/(\d{4})/);
                if (dataMatch) {
                    const dia = parseInt(dataMatch[1]);
                    const mes = parseInt(dataMatch[2]);
                    const ano = parseInt(dataMatch[3]);
                    
                    agendamento.mes = mes;
                    agendamento.ano = ano;
                    agendamento.dataInicial = new Date(ano, mes - 1, dia);
                }
            }

            // Atendimento - Particular (corrige "Pa..." para "Particular")
            if (cleanLine.includes('Atendimento') && cleanLine.includes('R$')) {
                // Corrige "Pa..." para "Particular"
                const corrigido = cleanLine.replace(/\bPa\.{3}\b/g, 'Particular');
                agendamento.tipoConvenio = corrigido.includes('Particular') ? 'Particular' : 'Outros';
                
                // Extrai valor
                const valorMatch = corrigido.match(/R\$\s*([\d,.]+)/);
                if (valorMatch) {
                    const valorStr = valorMatch[1].replace(/\./g, '').replace(',', '.');
                    agendamento.valorAtendimento = parseFloat(valorStr);
                }
            }
        });

        // Define se é pagante (não é isento e tem valor ou convênio não é isento)
        agendamento.isPagante = !agendamento.isIsento && agendamento.valorAtendimento > 0;

        // Se não tiver mês/ano definido, usa data de processamento
        if (!agendamento.mes || !agendamento.ano) {
            const hoje = new Date();
            agendamento.mes = hoje.getMonth() + 1;
            agendamento.ano = hoje.getFullYear();
        }

        // Valida campos essenciais
        if (!agendamento.horario || !agendamento.paciente) {
            return null;
        }

        return agendamento;
    }

    /**
     * Processa múltiplas mensagens de uma vez
     * @param {string} content - Conteúdo com múltiplas mensagens
     * @returns {Array} Array de agendamentos
     */
    parseMultiple(content) {
        if (!content || content.trim() === '') {
            return [];
        }

        const agendamentos = [];
        const lines = content.split('\n');
        
        let i = 0;
        while (i < lines.length) {
            const line = lines[i].trim();
            
            // Detecta início de um novo bloco (linha de horário)
            if (line.startsWith('Horário:')) {
                // Coleta todas as linhas deste bloco até encontrar outro "Horário:" ou fim
                let blocoLines = [line];
                let j = i + 1;
                
                while (j < lines.length) {
                    const nextLine = lines[j].trim();
                    
                    // Para se encontrar outro horário (início de novo bloco)
                    if (nextLine.startsWith('Horário:')) {
                        break;
                    }
                    
                    blocoLines.push(lines[j]);
                    j++;
                    
                    // Limita a 20 linhas por bloco (segurança)
                    if (blocoLines.length >= 20) {
                        break;
                    }
                }
                
                // Junta as linhas do bloco e faz o parse
                const blocoContent = blocoLines.join('\n');
                const agendamento = this.parse(blocoContent);
                
                if (agendamento) {
                    agendamentos.push(agendamento);
                    console.log(`✅ Agendamento parseado: ${agendamento.horario} - ${agendamento.paciente} - R$ ${agendamento.valorAtendimento.toFixed(2)}`);
                } else {
                    console.warn('⚠️ Bloco de agendamento ignorado - dados incompletos');
                }
                
                // Avança o índice para após o bloco processado
                i = j;
            } else {
                i++;
            }
        }
        
        console.log(`📊 Total de agendamentos encontrados: ${agendamentos.length}`);
        return agendamentos;
    }

    /**
     * Formata data para exibição
     * @param {Date} date 
     * @returns {string}
     */
    formatDate(date) {
        if (!(date instanceof Date)) return '';
        
        const dia = String(date.getDate()).padStart(2, '0');
        const mes = String(date.getMonth() + 1).padStart(2, '0');
        const ano = date.getFullYear();
        return `${dia}/${mes}/${ano}`;
    }

    /**
     * Formata valor monetário
     * @param {number} valor 
     * @returns {string}
     */
    formatMoeda(valor) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(valor);
    }

    /**
     * Retorna nome do mês
     * @param {number} mes - Número do mês (1-12)
     * @returns {string}
     */
    getNomeMes(mes) {
        const meses = [
            'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
            'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
        ];
        return meses[mes - 1] || '';
    }

    /**
     * Extrai especialidade do procedimento
     * @param {string} procedimento 
     * @returns {string}
     */
    extrairEspecialidade(procedimento) {
        if (!procedimento) return 'Não especificado';

        // Padrões comuns
        const patterns = [
            { regex: /músculoesquelética/i, nome: 'Fisioterapia Músculoesquelética' },
            { regex: /neurológica/i, nome: 'Fisioterapia Neurológica' },
            { regex: /respiratória/i, nome: 'Fisioterapia Respiratória' },
            { regex: /cardíaca/i, nome: 'Fisioterapia Cardíaca' },
            { regex: /pélvica/i, nome: 'Fisioterapia Pélvica' },
            { regex: /geriátrica/i, nome: 'Fisioterapia Geriátrica' },
            { regex: /pediátrica/i, nome: 'Fisioterapia Pediátrica' },
            { regex: /desportiva/i, nome: 'Fisioterapia Desportiva' },
            { regex: /dermato/i, nome: 'Fisioterapia Dermatofuncional' },
            { regex: /pilates/i, nome: 'Pilates' },
            { regex: /rpg/i, nome: 'RPG' },
            { regex: /acupuntura/i, nome: 'Acupuntura' }
        ];

        for (const pattern of patterns) {
            if (pattern.regex.test(procedimento)) {
                return pattern.nome;
            }
        }

        return 'Fisioterapia Geral';
    }

    /**
     * Valida mensagem antes de processar
     * @param {string} content 
     * @returns {Object} {valido: boolean, erro: string}
     */
    validar(content) {
        if (!content || content.trim() === '') {
            return { valido: false, erro: 'Mensagem vazia' };
        }

        // Verifica campos obrigatórios
        const temHorario = /Horário:/i.test(content);
        const temPaciente = /Paciente:/i.test(content);

        if (!temHorario) {
            return { valido: false, erro: 'Campo "Horário" não encontrado' };
        }

        if (!temPaciente) {
            return { valido: false, erro: 'Campo "Paciente" não encontrado' };
        }

        return { valido: true, erro: '' };
    }
}

// Exporta a classe para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AgendamentoParser;
}
