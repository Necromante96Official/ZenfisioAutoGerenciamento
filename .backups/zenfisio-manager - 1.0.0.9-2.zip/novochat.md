Olá meu amigo, bom dia, tudo bom? Preciso da sua extrema ajuda em desenvolver uma ferramenta usando HTML, CSS, JS e PYTHON, para uso pessoal voltado ao trabalho de uma empresa que presto serviço. 
O plano é, criar uma pagina bem estruturada, onde vai ter opções, que façam analise de dados tanto financeiro, quanto organizações, com base em dados enviado por escrito em um formato.
O conceito é bem simples, podemos ir criando aos poucos, passo a apaso.
Mas primeiro vamos começar pela base real, preciso que crie todas as pastas, pois quero que seja totalmente organizado, modular, com tudo que for criado em pastas reservadas para eles.
Não quero que fique focando em criar arquivos descrevendo as coisas, guias, sumarios, arquivos gerais de documentações, não.. o plano é focar em programar e não contar hisória ok? Crie todos os arquivos nessa pasta (C:\Users\Clinica\Desktop\= Lucas Tavares =\Automação 2\zenfisio-manager), focaremos apenas nela.
