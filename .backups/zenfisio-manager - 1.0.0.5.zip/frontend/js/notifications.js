/**
 * NOTIFICATIONS.JS
 * Sistema de notificações flutuantes no topo direito da tela
 */

class NotificationSystem {
    constructor() {
        this.container = this.createContainer();
        this.queue = [];
        this.currentNotification = null;
    }

    createContainer() {
        const container = document.createElement('div');
        container.id = 'notification-container';
        container.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 10000;
            pointer-events: none;
            display: flex;
            flex-direction: column;
            gap: 12px;
            align-items: flex-end;
            max-width: 420px;
        `;
        document.body.appendChild(container);
        return container;
    }

    show(message, type = 'info', duration = 4000) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        
        // Ícones por tipo
        const icons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };

        const icon = icons[type] || 'ℹ️';
        notification.innerHTML = `<span class="notification-icon">${icon}</span><span class="notification-text">${message}</span>`;
        
        // Calcula delay baseado no número de notificações
        const notificationCount = this.container.children.length;
        const delay = notificationCount * 50; // 50ms de delay entre cada uma

        notification.style.cssText = `
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 300px;
            max-width: 400px;
            padding: 12px 16px;
            background: ${this.getBackgroundColor(type)};
            color: ${this.getTextColor(type)};
            border: 1px solid ${this.getBorderColor(type)};
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            font-size: 0.9rem;
            font-weight: 500;
            animation: slideInRight 0.3s ease-out forwards;
            animation-delay: ${delay}ms;
            pointer-events: all;
            transition: all 0.3s ease;
            word-wrap: break-word;
            overflow-wrap: break-word;
        `;

        this.container.appendChild(notification);

        // Auto-remove após duration
        const timeoutId = setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-out forwards';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, duration + delay); // Adiciona delay ao tempo total

        // Click para remover
        notification.addEventListener('click', () => {
            clearTimeout(timeoutId);
            notification.style.animation = 'slideOutRight 0.3s ease-out forwards';
            setTimeout(() => {
                notification.remove();
            }, 300);
        });

        return notification;
    }

    success(message, duration = 4000) {
        return this.show(message, 'success', duration);
    }

    error(message, duration = 5000) {
        return this.show(message, 'error', duration);
    }

    warning(message, duration = 4000) {
        return this.show(message, 'warning', duration);
    }

    info(message, duration = 3000) {
        return this.show(message, 'info', duration);
    }

    getBackgroundColor(type) {
        const colors = {
            success: 'rgba(76, 175, 80, 0.95)',
            error: 'rgba(244, 67, 54, 0.95)',
            warning: 'rgba(255, 193, 7, 0.95)',
            info: 'rgba(47, 190, 143, 0.95)'
        };
        return colors[type] || colors.info;
    }

    getTextColor(type) {
        const colors = {
            success: '#ffffff',
            error: '#ffffff',
            warning: '#000000',
            info: '#ffffff'
        };
        return colors[type] || colors.info;
    }

    getBorderColor(type) {
        const colors = {
            success: 'rgba(76, 175, 80, 0.4)',
            error: 'rgba(244, 67, 54, 0.4)',
            warning: 'rgba(255, 193, 7, 0.4)',
            info: 'rgba(47, 190, 143, 0.4)'
        };
        return colors[type] || colors.info;
    }
}

// Instância global
let notificationSystem;

document.addEventListener('DOMContentLoaded', () => {
    notificationSystem = new NotificationSystem();
    window.notify = notificationSystem;
});

// Para uso antes do DOMContentLoaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        if (!notificationSystem) {
            notificationSystem = new NotificationSystem();
            window.notify = notificationSystem;
        }
    });
}
