/**
 * Financial Integration - Integra parser, analyzer e UI
 */

class FinancialIntegration {
    constructor() {
        this.parser = new FinancialParser();
        this.analyzer = new FinancialAnalyzer();
        this.ui = new FinancialUI();
    }

    /**
     * Processa dados financeiros
     */
    processData(text, silent = false) {
        try {
            // Parse
            const records = this.parser.parse(text);
            
            if (records.length === 0) {
                if (!silent) {
                    this.showNotification('Nenhum registro encontrado', 'warning');
                }
                return;
            }

            // Filter confirmed (usando parser que já filtrou)
            const confirmedRecords = this.parser.getConfirmedRecords();
            
            if (confirmedRecords.length === 0) {
                if (!silent) {
                    this.showNotification('Nenhum registro com "Presença confirmada"', 'warning');
                }
                return;
            }

            // Analyze (passa confirmed records que já estão filtrados)
            this.analyzer = new FinancialAnalyzer(confirmedRecords);
            const analysis = this.analyzer.analyze();

            // Verifica se gerou alguma análise
            if (!analysis.summary || analysis.summary.totalAtendimentos === 0) {
                if (!silent) {
                    this.showNotification('Nenhum dado para análise', 'warning');
                }
                return;
            }

            // Salva dados (sem deixar falhas afetarem notificação)
            try {
                if (window.dataManager) {
                    window.dataManager.addFinanceiro(analysis);
                }
            } catch (saveError) {
                console.warn('Aviso ao salvar dados financeiros:', saveError);
            }

            // Render
            this.ui.render(analysis);

            // Mostra notificação apenas se não for silencioso
            if (!silent) {
                this.showNotification(`✅ ${confirmedRecords.length} registros processados com sucesso!`, 'success');
            }
        } catch (error) {
            console.error('Erro na análise financeira:', error);
            if (!silent) {
                this.showNotification('Erro ao processar dados financeiros', 'error');
            }
        }
    }

    /**
     * Show notification
     */
    showNotification(message, type = 'info') {
        if (window.notificationSystem) {
            window.notificationSystem.show(message, type);
        } else if (window.notify) {
            window.notify.show(message, type);
        }
    }

    /**
     * Get summary
     */
    getSummary() {
        return this.analyzer.getSummary();
    }

    /**
     * Get specialties
     */
    getSpecialties() {
        return this.analyzer.getSpecialties();
    }

    /**
     * Get professionals
     */
    getProfessionals() {
        return this.analyzer.getProfessionals();
    }

    /**
     * Get patients
     */
    getPatients() {
        return this.analyzer.getPatients();
    }
}

// Initialize on document load
document.addEventListener('DOMContentLoaded', () => {
    window.FinancialIntegration = new FinancialIntegration();
});
