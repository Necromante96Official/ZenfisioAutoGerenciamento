/**
 * EVOLUCOES-INTEGRATION.JS
 * Integra o sistema de evoluções com a interface existente
 */

class EvolucoesIntegration {
    constructor() {
        this.analyzer = new EvolucoesAnalyzer();
        this.ui = null;
        this.parser = new AgendamentoParser();
        this.init();
    }

    init() {
        // Aguarda DOM estar pronto
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }
    }

    setup() {
        // Cria a UI
        this.ui = new EvolucoesUI(this.analyzer);

        // Conecta os botões
        const processBtn = document.getElementById('processBtn');
        const clearBtn = document.getElementById('clearBtn');
        const textarea = document.getElementById('evolucaoTextarea');

        if (processBtn) {
            processBtn.addEventListener('click', () => this.processar());
        }

        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.limpar());
        }

        // Enter em Ctrl+Enter para processar (opcional)
        if (textarea) {
            textarea.addEventListener('keydown', (e) => {
                if (e.ctrlKey && e.key === 'Enter') {
                    this.processar();
                }
            });
        }

        console.log('✅ Sistema de Evoluções integrado');
    }

    processar() {
        const textarea = document.getElementById('evolucaoTextarea');

        if (!textarea) return;

        const content = textarea.value.trim();

        if (!content) {
            this.mostrarNotificacao('Cole um conteúdo válido', 'warning');
            return;
        }

        // Valida a entrada
        const validacao = this.parser.validar(content);
        if (!validacao.valido) {
            this.mostrarNotificacao(`${validacao.erro}`, 'error');
            return;
        }

        try {
            // Parse dos dados
            const agendamentos = this.parser.parseMultiple(content);

            if (agendamentos.length === 0) {
                this.mostrarNotificacao('Nenhum agendamento válido encontrado', 'warning');
                return;
            }

            // Obtém a data do date manager
            if (window.dateManager) {
                const currentDate = window.dateManager.getDate();
                const dia = String(currentDate.getDate()).padStart(2, '0');
                const mes = String(currentDate.getMonth() + 1).padStart(2, '0');
                const ano = currentDate.getFullYear();

                // Adiciona a data do date picker a cada agendamento
                agendamentos.forEach(agendamento => {
                    agendamento.mes = parseInt(mes);
                    agendamento.ano = ano;
                    agendamento.dataProcessamento = `${dia}/${mes}/${ano}`;
                });
            }

            // Processa no analyzer
            const resultado = this.analyzer.processarMultiplas(agendamentos);

            // Salva dados (sem deixar falhas afetarem notificação)
            try {
                if (window.dataManager) {
                    window.dataManager.addEvolucoes(this.analyzer.getEvolucoes());
                }
            } catch (saveError) {
                console.warn('Aviso ao salvar dados:', saveError);
            }

            // Mostra notificação de sucesso
            const msg = `${resultado.sucesso} evoluções adicionadas, ${resultado.ignoradas} ignoradas`;
            this.mostrarNotificacao(msg, 'success');

            // Atualiza a UI
            this.ui.switchTab('visao-geral');
            this.ui.refresh();

            // NOVO: Processa dados financeiros também (sem mostrar notificação dupla)
            if (window.FinancialIntegration && window.FinancialIntegration instanceof FinancialIntegration) {
                try {
                    window.FinancialIntegration.processData(content, true); // true = silencioso
                } catch (finError) {
                    console.warn('Aviso ao processar dados financeiros:', finError);
                }
            }

            // Log das estatísticas
            const stats = this.analyzer.getEstatisticas();
            console.log('📊 Estatísticas:', stats);

        } catch (erro) {
            console.error('Erro ao processar:', erro);
            this.mostrarNotificacao(`Erro ao processar: ${erro.message}`, 'error');
        }
    }

    limpar() {
        const textarea = document.getElementById('evolucaoTextarea');

        if (textarea) {
            textarea.value = '';
            textarea.focus();
        }

        this.analyzer.limpar();
        this.ui.refresh();

        this.mostrarNotificacao('Dados limpos com sucesso', 'info');
    }

    mostrarNotificacao(texto, tipo = 'info') {
        // Usa o sistema de notificações flutuante
        if (window.notify) {
            window.notify[tipo](texto);
        } else {
            // Fallback apenas se o sistema não estiver disponível
            console.warn('Sistema de notificações não inicializado:', texto);
        }
    }

    /**
     * Exporta dados para análise financeira (futura integração)
     */
    exportarParaFinanceiro() {
        const dados = this.analyzer.exportarJSON();
        console.log('📊 Dados exportados para análise financeira');
        return dados;
    }
}

// Inicializa quando o DOM estiver pronto
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.evolucoesIntegration = new EvolucoesIntegration();
    });
} else {
    window.evolucoesIntegration = new EvolucoesIntegration();
}
