# Backend initialization
