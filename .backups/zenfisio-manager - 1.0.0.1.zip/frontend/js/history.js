/**
 * HISTÓRICO DE ATUALIZAÇÕES
 * Gerencia a exibição e interatividade do modal de histórico de versões
 */

class HistoryManager {
    constructor() {
        this.historyModal = document.getElementById('historyModal');
        this.historyContent = document.getElementById('historyContent');
        this.closeHistoryBtn = document.getElementById('closeHistory');
        this.versionBadge = document.querySelector('.version-badge');
        this.versions = this.getVersions();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.renderVersions();
    }

    setupEventListeners() {
        // Abrir histórico ao clicar na versão
        if (this.versionBadge) {
            this.versionBadge.addEventListener('click', () => this.openHistory());
        }

        // Fechar histórico
        this.closeHistoryBtn.addEventListener('click', () => this.closeHistory());

        // Fechar ao clicar fora
        this.historyModal.addEventListener('click', (e) => {
            if (e.target === this.historyModal) {
                this.closeHistory();
            }
        });

        // Fechar com ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.historyModal.classList.contains('active')) {
                this.closeHistory();
            }
        });
    }

    getVersions() {
        return [
            {
                version: '1.0.0.1',
                date: '10 de novembro de 2025',
                title: 'Aprimoramentos de Interface & Acessibilidade',
                features: [
                    'Esquema de cores verde Zenfisio em todo o sistema',
                    'Layout horizontal aprimorado de modais (max-width 1000px)',
                    'Cards de termos com funcionalidade expandível/colapsável',
                    'Conteúdo de termos reescrito em linguagem profissional',
                    'Título "Evoluções Pendentes" centralizado e animado',
                    'Animações fluidas sincronizadas com logo "Auto Gerenciamento"',
                    'Gradiente de texto nos títulos (verde Zenfisio)',
                    'Neon verde sutil atrás de títulos (sem ofuscação)',
                    'Modal histórico com layout 2-column mais horizontal',
                    'Botão de versão (📦) com animação shine sutilizada',
                    'Cards de termos com grid layout (icon + conteúdo)',
                    'Icons maiores (1.4rem) nos cards de termos',
                    'Expand/collapse com ícone animado (▼)',
                    'Pulso sutil e harmônico nos títulos (2.5s)',
                    'Redução de padding em card-header (1.5rem → 1rem)',
                    'Opacidade reduzida do neon background'
                ],
                description: 'Segunda versão focada em refinamento visual e profissionalismo. Implementação de layout horizontal mais eficiente, tema verde Zenfisio completo, cards expandíveis nos termos e sincronização de animações com o logo do sistema.',
                improvements: [
                    'Interface 100% verde Zenfisio (#2fbe8f) - redução de poluição visual',
                    'Modais mais horizontais (600px → 900-1000px max-width)',
                    'Conteúdo de termos agora com contexto profissional completo',
                    'Cards de termos expandíveis para melhor organização',
                    'Animações sincronizadas (slideDown, pulse-subtle)',
                    'Neon background com opacidade reduzida (0.15 → 0.08)',
                    'Hierarquia visual clara com títulos gradiente',
                    'Espaçamento otimizado (padding 1.5rem → 1rem)',
                    'Acessibilidade melhorada (dark/light theme)',
                    'Profissionalismo aumentado em documentação de termos',
                    'UX melhorada com expand/collapse intuitivo',
                    'Animações mais sutis e focadas (evita fadiga visual)'
                ]
            },
            {
                version: '1.0.0.0',
                date: '10 de novembro de 2025',
                title: 'Lançamento Inicial',
                features: [
                    'Dashboard moderno com interface dark/light',
                    'Sistema de tema claro e escuro com persistência',
                    'Controles de data avançados (navegação mensal e diária)',
                    'Processamento e análise de evoluções pendentes',
                    'Design responsivo para mobile, tablet e desktop',
                    'Animações fluidas e transições suaves',
                    'Modal de termos com conteúdo detalhado',
                    'Sistema de feedback visual (notificações)',
                    'Arquitetura modular com 6 módulos JavaScript',
                    'Efeitos neon animados no background',
                    'Cards com hover effects e gradientes',
                    'Sistema de botões com ripple effect',
                    'Footer profissional com informações do sistema',
                    'Validação de dados em tempo real',
                    'API de integração com backend Python'
                ],
                description: 'Lançamento da primeira versão do Auto Gerenciamento - Zenfisio Manager. Sistema completo para análise de dados de fisioterapia com interface moderna e funcionalidades avançadas de processamento.',
                improvements: [
                    'Interface intuitiva e fácil de usar para equipe clínica',
                    'Tema dark como padrão para reduzir fadiga visual',
                    'Sistema de cores bem definido (azul primário, sucesso verde, alerta amarelo)',
                    'Transições suaves (150ms-500ms) para melhor UX',
                    'Suporte a acessibilidade (prefers-reduced-motion)',
                    'Estrutura HTML semântica para melhor SEO'
                ]
            }
        ];
    }

    renderVersions() {
        // Renderizar de baixo para cima (versões mais recentes embaixo)
        const reversedVersions = [...this.versions].reverse();

        this.historyContent.innerHTML = reversedVersions.map((version, index) => `
            <div class="history-item" data-version="${version.version}">
                <div class="history-version-header">
                    <div class="history-version-info">
                        <div class="history-version-number">Versão ${version.version}</div>
                        <div class="history-version-date">📅 ${version.date}</div>
                    </div>
                    <div class="history-toggle-icon">▼</div>
                </div>
                <div class="history-version-details">
                    <div class="history-details-content">
                        <div class="history-section">
                            <div class="history-section-title">
                                <span class="history-section-icon">📝</span>
                                <span>Sobre esta versão</span>
                            </div>
                            <p class="history-feature-description">${version.description}</p>
                        </div>

                        <div class="history-section">
                            <div class="history-section-title">
                                <span class="history-section-icon">✨</span>
                                <span>Novas Funcionalidades</span>
                            </div>
                            <ul class="history-feature-list">
                                ${version.features.map(feature => `
                                    <li class="history-feature-item">${feature}</li>
                                `).join('')}
                            </ul>
                        </div>

                        <div class="history-section">
                            <div class="history-section-title">
                                <span class="history-section-icon">🎯</span>
                                <span>Melhorias & Otimizações</span>
                            </div>
                            <ul class="history-feature-list">
                                ${version.improvements.map(improvement => `
                                    <li class="history-feature-item">${improvement}</li>
                                `).join('')}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');

        // Adicionar event listeners aos headers
        this.setupVersionToggle();
    }

    setupVersionToggle() {
        const headers = this.historyContent.querySelectorAll('.history-version-header');
        headers.forEach(header => {
            header.addEventListener('click', () => {
                const item = header.closest('.history-item');
                item.classList.toggle('expanded');
            });
        });
    }

    openHistory() {
        this.historyModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    closeHistory() {
        this.historyModal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    new HistoryManager();
});
