/**
 * EVOLUCOES-UI.JS
 * Gerencia a interface de abas e renderização do conteúdo de evoluções
 */

class EvolucoesUI {
    constructor(analyzerInstance) {
        this.analyzer = analyzerInstance;
        this.currentTab = 'visao-geral';
        this.init();
    }

    init() {
        this.setupTabs();
        this.setupEventListeners();
    }

    setupTabs() {
        const tabsContainer = document.querySelector('.evolucoes-tabs');
        if (!tabsContainer) return;

        const tabs = ['visao-geral', 'pacientes', 'fisioterapeutas', 'cronologia'];
        
        tabs.forEach(tab => {
            const btn = document.querySelector(`[data-tab="${tab}"]`);
            if (btn) {
                btn.addEventListener('click', () => this.switchTab(tab));
            }
        });
    }

    setupEventListeners() {
        // Listeners para botões de expansão
        document.addEventListener('click', (e) => {
            if (e.target.closest('.card-expand-btn')) {
                const btn = e.target.closest('.card-expand-btn');
                const details = btn.closest('.card-details').previousElementSibling;
                if (details?.classList.contains('card-details')) {
                    details.classList.toggle('expanded');
                    btn.textContent = details.classList.contains('expanded') 
                        ? '▼ Menos detalhes' 
                        : '▶ Mais detalhes';
                }
            }
        });
    }

    switchTab(tabName) {
        this.currentTab = tabName;

        // Atualizar botões
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.tab === tabName) {
                btn.classList.add('active');
            }
        });

        // Atualizar conteúdo
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });

        const tabContent = document.querySelector(`[data-tab-content="${tabName}"]`);
        if (tabContent) {
            tabContent.classList.add('active');
            this.renderTab(tabName);
        }
    }

    renderTab(tabName) {
        const container = document.querySelector(`[data-tab-content="${tabName}"]`);
        if (!container) return;

        switch (tabName) {
            case 'visao-geral':
                this.renderVisaoGeral(container);
                break;
            case 'pacientes':
                this.renderPacientes(container);
                break;
            case 'fisioterapeutas':
                this.renderFisioterapeutas(container);
                break;
            case 'cronologia':
                this.renderCronologia(container);
                break;
        }
    }

    renderVisaoGeral(container) {
        const data = this.analyzer.getVisaoGeral();

        if (data.totalAtendimentos === 0) {
            container.innerHTML = this.getEmptyState('Nenhuma evolução processada ainda');
            return;
        }

        let html = this.getStatsBar(data) + `
            <div class="visao-geral-container">
                <div class="visao-geral-column">
                    <h4>👥 Pacientes com Falta de Evolução (${data.pacientes.length})</h4>
                    <div style="display: flex; flex-direction: column; gap: 0.75rem;">
        `;

        data.pacientes.forEach(paciente => {
            html += `
                <div class="visao-geral-item">
                    <div class="visao-item-nome">${paciente.nome}</div>
                    <div class="visao-item-info">
                        <div class="visao-item-stat">
                            <div class="visao-item-stat-label">Atendimentos</div>
                            <div class="visao-item-stat-value">${paciente.totalAtendimentos}</div>
                        </div>
                    </div>
                    <div class="visao-item-list">
                        <div class="visao-item-list-title">Fisioterapeutas:</div>
                        <div class="visao-item-list-items">
                            ${paciente.fisioterapeutas.map(f => `<span>• ${f}</span>`).join('')}
                        </div>
                    </div>
                </div>
            `;
        });

        html += `
                    </div>
                </div>
                <div class="visao-geral-column">
                    <h4>👨‍⚕️ Fisioterapeutas com Falta de Evoluções (${data.fisioterapeutas.length})</h4>
                    <div style="display: flex; flex-direction: column; gap: 0.75rem;">
        `;

        data.fisioterapeutas.forEach(fisio => {
            html += `
                <div class="visao-geral-item">
                    <div class="visao-item-nome">${fisio.nome}</div>
                    <div class="visao-item-info">
                        <div class="visao-item-stat">
                            <div class="visao-item-stat-label">Atendimentos</div>
                            <div class="visao-item-stat-value">${fisio.totalAtendimentos}</div>
                        </div>
                        <div class="visao-item-stat">
                            <div class="visao-item-stat-label">Pacientes</div>
                            <div class="visao-item-stat-value">${fisio.totalPacientes}</div>
                        </div>
                    </div>
                    <div class="visao-item-list">
                        <div class="visao-item-list-title">Pacientes:</div>
                        <div class="visao-item-list-items">
                            ${fisio.pacientes.map(p => `<span>• ${p}</span>`).join('')}
                        </div>
                    </div>
                </div>
            `;
        });

        html += `
                    </div>
                </div>
            </div>
        `;

        container.innerHTML = html;
    }

    renderPacientes(container) {
        const pacientes = this.analyzer.getPacientes();

        if (pacientes.length === 0) {
            container.innerHTML = this.getEmptyState('Nenhum paciente encontrado');
            return;
        }

        let html = this.getStatsBar({ totalPacientesUnicos: pacientes.length, totalAtendimentos: this.analyzer.evolucoes.length }) + `
            <div class="patients-grid">
        `;

        pacientes.forEach((paciente, index) => {
            html += `
                <div class="patient-card" style="animation-delay: ${index * 50}ms">
                    <div class="card-patient-header">
                        <div class="card-patient-name">${paciente.nome}</div>
                        <div class="card-patient-badge">${paciente.totalAtendimentos}</div>
                    </div>
                    <div class="card-patient-info">
                        <div class="card-info-item">
                            <span class="card-info-label">Atendimentos</span>
                            <span class="card-info-value">${paciente.totalAtendimentos}x</span>
                        </div>
                        <div class="card-info-item">
                            <span class="card-info-label">Fisios</span>
                            <span class="card-info-value">${paciente.fisioterapeutas.split(', ').length}</span>
                        </div>
                        <div class="card-info-item">
                            <span class="card-info-label">Período</span>
                            <span class="card-info-value multi-line">
                                ${paciente.datas.map(d => `<span>${d}</span>`).join('')}
                            </span>
                        </div>
                    </div>
                    <div class="card-expandable">
                        <button class="card-expand-btn">▶ Mais detalhes</button>
                        <div class="card-details">
                            ${paciente.atendimentos.map(at => `
                                <div class="detail-item">
                                    <span class="detail-label">${at.data}</span>
                                    <span class="detail-value">${at.fisioterapeuta} (${at.horario})</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        });

        html += `</div>`;
        container.innerHTML = html;
    }

    renderFisioterapeutas(container) {
        const fisios = this.analyzer.getFisioterapeutas();

        if (fisios.length === 0) {
            container.innerHTML = this.getEmptyState('Nenhum fisioterapeuta encontrado');
            return;
        }

        let html = this.getStatsBar({ totalFisioterapeutasUnicos: fisios.length, totalAtendimentos: this.analyzer.evolucoes.length }) + `
            <div class="therapists-grid">
        `;

        fisios.forEach((fisio, index) => {
            html += `
                <div class="therapist-card" style="animation-delay: ${index * 50}ms">
                    <div class="card-therapist-header">
                        <div class="card-therapist-name">${fisio.nome}</div>
                        <div class="card-therapist-badge">${fisio.totalAtendimentos}</div>
                    </div>
                    <div class="card-therapist-info">
                        <div class="card-info-item">
                            <span class="card-info-label">Atendimentos</span>
                            <span class="card-info-value">${fisio.totalAtendimentos}x</span>
                        </div>
                        <div class="card-info-item">
                            <span class="card-info-label">Pacientes</span>
                            <span class="card-info-value">${fisio.totalPacientes}</span>
                        </div>
                        <div class="card-info-item">
                            <span class="card-info-label">Período</span>
                            <span class="card-info-value multi-line">
                                ${fisio.datas.map(d => `<span>${d}</span>`).join('')}
                            </span>
                        </div>
                    </div>
                    <div class="card-expandable">
                        <button class="card-expand-btn">▶ Mais detalhes</button>
                        <div class="card-details">
                            ${fisio.atendimentos.map(at => `
                                <div class="detail-item">
                                    <span class="detail-label">${at.data}</span>
                                    <span class="detail-value">${at.paciente} (${at.horario})</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        });

        html += `</div>`;
        container.innerHTML = html;
    }

    renderCronologia(container) {
        const cronologia = this.analyzer.getCronologia();
        const datas = Object.keys(cronologia);

        if (datas.length === 0) {
            container.innerHTML = this.getEmptyState('Nenhum item na cronologia');
            return;
        }

        let html = `<div class="cronologia-timeline">`;

        datas.forEach((data, dataIndex) => {
            html += `
                <div>
                    <div class="timeline-date">${data}</div>
                    <div class="timeline-items">
            `;

            cronologia[data].forEach((item, itemIndex) => {
                html += `
                    <div class="timeline-item" style="animation-delay: ${(dataIndex * cronologia[data].length + itemIndex) * 30}ms">
                        <div class="timeline-item-time">⏰ ${item.horario}</div>
                        <div class="timeline-item-details">
                            <div class="timeline-item-detail">
                                <div class="timeline-detail-label">Paciente</div>
                                <div class="timeline-detail-value">${item.paciente}</div>
                            </div>
                            <div class="timeline-item-detail">
                                <div class="timeline-detail-label">Fisioterapeuta</div>
                                <div class="timeline-detail-value">${item.fisioterapeuta}</div>
                            </div>
                            <div class="timeline-item-detail">
                                <div class="timeline-detail-label">Convênio</div>
                                <div class="timeline-detail-value">${item.convenio || 'N/A'}</div>
                            </div>
                        </div>
                    </div>
                `;
            });

            html += `
                    </div>
                </div>
            `;
        });

        html += `</div>`;
        container.innerHTML = html;
    }

    getStatsBar(data) {
        return `
            <div class="stats-summary">
                <div class="stat-box">
                    <div class="stat-box-value">${data.totalAtendimentos || this.analyzer.evolucoes.length}</div>
                    <div class="stat-box-label">Total de Atendimentos</div>
                </div>
                <div class="stat-box">
                    <div class="stat-box-value">${data.totalPacientesUnicos || data.pacientes?.length || this.analyzer.pacientes.size}</div>
                    <div class="stat-box-label">Pacientes Únicos</div>
                </div>
                <div class="stat-box">
                    <div class="stat-box-value">${data.totalFisioterapeutasUnicos || data.fisioterapeutas?.length || this.analyzer.fisioterapeutas.size}</div>
                    <div class="stat-box-label">Fisioterapeutas</div>
                </div>
            </div>
        `;
    }

    getEmptyState(message) {
        return `
            <div class="empty-state">
                <div class="empty-state-icon">📭</div>
                <div class="empty-state-title">Nenhum dado</div>
                <div class="empty-state-text">${message}</div>
            </div>
        `;
    }

    /**
     * Atualiza toda a interface após novo processamento
     */
    refresh() {
        this.renderTab(this.currentTab);
        console.log('✅ Interface atualizada');
    }
}

// Exporta a classe para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EvolucoesUI;
}
