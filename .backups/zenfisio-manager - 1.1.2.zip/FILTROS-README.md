# Sistema Unificado de Filtros Avançados

Sistema completo de filtros para todas as páginas do Zenfisio Manager.

## 📋 Estrutura

### Arquivos Criados

#### JavaScript
- `frontend/js/unified-filter-modal.js` - Modal unificado com 3 abas
- `frontend/js/unified-filter-system.js` - Lógica de aplicação de filtros
- `frontend/js/unified-filter-integration.js` - Integração com módulos

#### CSS
- `css/unified-filter-modal.css` - Estilos do modal extenso
- `css/styles.css` - Adicionado botão global e responsividade

#### HTML
- `index.html` - Botão global de filtros no header

## 🎯 Funcionalidades

### Aba Agendamentos
✅ **Filtros Rápidos de Período**
- 📅 Dia Específico
- 📆 Semana (Seg-Sex)
- 🗓️ 15 Dias úteis (Seg-Sex)
- 📊 Mês Completo
- 📈 Ano Completo

✅ **Filtros Manuais**
- Data: Dia / Mês / Ano
- Intervalo: Data Início → Data Fim
- Status: Compareceu / Faltou
- Fisioterapeuta: busca parcial
- Paciente: busca parcial

### Aba Evoluções Pendentes
✅ **Filtros Disponíveis**
- Data: Dia / Mês / Ano
- Paciente: busca parcial
- Fisioterapeuta: busca parcial

### Aba Análise Financeira
✅ **Filtros Disponíveis**
- Data: Dia / Mês / Ano
- Valores: Mínimo / Máximo (R$)
- Profissional: busca parcial
- Convênio: busca parcial

## 🚀 Como Usar

1. **Clique no botão "🔍 Filtros"** no header (topo direito)
2. **Escolha a aba** desejada (Evoluções, Financeiro ou Agendamentos)
3. **Configure os filtros** que deseja aplicar
4. **Clique em "✓ Aplicar Filtros"**
5. **Para limpar:** clique em "✕ Limpar Filtros"

## 🔧 Implementação Técnica

### Fluxo de Dados

```
Botão Global → Modal Unificado → Sistema de Filtros → Módulo Específico
     ↓              ↓                    ↓                    ↓
  Detecta      Renderiza           Processa            Atualiza UI
  módulo        aba ativa          filtros              com dados
  ativo                           em dados            filtrados
```

### Arquitetura

**UnifiedFilterModal**
- Gerencia interface do modal
- 3 abas independentes
- Coleta inputs do usuário

**UnifiedFilterSystem**
- Aplica filtros aos dados
- Preserva dados originais
- Re-renderiza UIs

**UnifiedFilterIntegration**
- Conecta botão ao modal
- Define callbacks por módulo
- Detecta módulo ativo

## 📊 Filtros por Data

### Agendamentos
- Usa `dataSelecionada` do agendamento
- Fallback para `dia/mes/ano`
- Suporta intervalos de datas

### Período Rápido
- **Dia**: data atual
- **Semana**: segunda a sexta da semana atual
- **15 Dias**: 15 dias úteis a partir de hoje
- **Mês**: primeiro ao último dia do mês
- **Ano**: 1º de janeiro a 31 de dezembro

## 🎨 Interface

### Modal
- Centralizado na tela
- Largura máxima: 800px
- Altura máxima: 90vh
- Scrollável
- Animações suaves

### Tabs
- 3 abas: Evoluções / Financeiro / Agendamentos
- Indicador visual de aba ativa
- Transições animadas

### Botões Rápidos
- Grid responsivo
- Destaque visual ao clicar
- Feedback imediato

## 📱 Responsividade

✅ Desktop (>768px)
- Modal: 800px max-width
- Grid de botões: auto-fit

✅ Mobile (≤768px)
- Modal: 95% da tela
- Botões em 2 colunas
- Footer empilhado

## 🔍 Preservação de Dados

- Dados originais mantidos no `DataManager`
- Filtros não alteram localStorage
- Botão "Limpar Filtros" restaura visualização completa
- Filtros independentes por módulo

## ⚙️ Integração

### Callbacks Configurados

```javascript
// Agendamentos
window.unifiedFilterModal.setCallback('agendamentos', (filters) => {
    window.unifiedFilterSystem.applyAgendamentosFilters(filters);
});

// Evoluções
window.unifiedFilterModal.setCallback('evolucoes', (filters) => {
    window.unifiedFilterSystem.applyEvolucoesFilters(filters);
});

// Financeiro
window.unifiedFilterModal.setCallback('financeiro', (filters) => {
    window.unifiedFilterSystem.applyFinanceiroFilters(filters);
});
```

## ✨ Melhorias Futuras

- [ ] Salvar filtros favoritos
- [ ] Histórico de filtros aplicados
- [ ] Exportar dados filtrados
- [ ] Filtros por tags/categorias
- [ ] Comparação entre períodos

---

**Desenvolvido para Zenfisio Manager v1.2.0**
